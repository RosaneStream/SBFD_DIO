package com.dio.santander.bankline.api.model;

public enum MovimentacaoTipo {
RECEITA,DESPESA
}
